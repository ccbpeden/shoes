-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Mar 04, 2017 at 01:03 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=303 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`brand_id`, `store_id`, `id`) VALUES
(174, 152, 1),
(182, 160, 2),
(190, 168, 4),
(191, 168, 5),
(198, 176, 6),
(206, 184, 8),
(223, 193, 11),
(223, 195, 12),
(224, 203, 13),
(226, 203, 14),
(7, 1, 15),
(7, 3, 16),
(8, 11, 17),
(10, 11, 18),
(17, 12, 19),
(17, 14, 20),
(18, 22, 21),
(20, 22, 22),
(27, 23, 23),
(27, 25, 24),
(36, 26, 25),
(36, 28, 26),
(39, 36, 27),
(41, 36, 28),
(48, 37, 29),
(48, 39, 30),
(52, 40, 32),
(53, 48, 33),
(55, 48, 34),
(62, 49, 35),
(62, 51, 36),
(66, 52, 38),
(67, 60, 39),
(69, 60, 40),
(70, 64, 42),
(77, 65, 43),
(77, 67, 44),
(81, 68, 46),
(82, 76, 47),
(84, 76, 48),
(85, 80, 50),
(92, 81, 51),
(92, 83, 52),
(96, 84, 54),
(97, 92, 55),
(99, 92, 56),
(100, 96, 58),
(107, 97, 59),
(107, 99, 60),
(111, 100, 62),
(112, 108, 63),
(114, 108, 64),
(115, 112, 66),
(122, 113, 67),
(122, 115, 68),
(126, 116, 70),
(127, 124, 71),
(129, 124, 72),
(130, 128, 74),
(137, 129, 75),
(137, 131, 76),
(141, 132, 78),
(142, 140, 79),
(144, 140, 80),
(145, 144, 82),
(152, 145, 83),
(152, 147, 84),
(156, 148, 86),
(157, 156, 87),
(159, 156, 88),
(160, 160, 90),
(167, 161, 91),
(167, 163, 92),
(171, 164, 94),
(172, 172, 95),
(174, 172, 96),
(175, 176, 98),
(182, 177, 99),
(182, 179, 100),
(186, 180, 102),
(187, 181, 103),
(187, 183, 104),
(188, 191, 105),
(190, 191, 106),
(191, 195, 108),
(198, 196, 109),
(198, 198, 110),
(202, 199, 112),
(203, 200, 113),
(203, 202, 114),
(204, 210, 115),
(206, 210, 116),
(207, 214, 118),
(214, 215, 119),
(214, 217, 120),
(218, 218, 122),
(219, 219, 123),
(219, 221, 124),
(220, 229, 125),
(222, 229, 126),
(223, 233, 128),
(230, 234, 129),
(230, 236, 130),
(234, 237, 132),
(235, 238, 133),
(235, 240, 134),
(236, 248, 135),
(238, 248, 136),
(239, 252, 138),
(246, 253, 139),
(246, 255, 140),
(250, 256, 142),
(251, 257, 143),
(251, 259, 144),
(252, 267, 145),
(254, 267, 146),
(255, 271, 148),
(262, 272, 149),
(262, 274, 150),
(266, 275, 152),
(267, 276, 153),
(267, 278, 154),
(268, 286, 155),
(270, 286, 156),
(271, 290, 158),
(278, 291, 159),
(278, 293, 160),
(282, 294, 162),
(283, 295, 163),
(283, 297, 164),
(284, 305, 165),
(286, 305, 166),
(287, 309, 168),
(294, 310, 169),
(294, 312, 170),
(298, 313, 172),
(299, 321, 173),
(301, 321, 174),
(302, 325, 176);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `store_name` varchar(255) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=326 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=303;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=177;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=326;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
